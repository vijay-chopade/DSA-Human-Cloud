package com.List;

public class Runner {

	public static void main(String[] args) {
//		LinkedList list = new LinkedList();
//		list.insert(9);
//		list.insert(4);
//		list.insert(6);
//		list.insert(2);
////		list.insertAtStart(88);
////		list.insertAtStart(77);
////		list.insertAt(3, 55);
////		list.show();
////		list.deleteAt(2);
////		list.show();
////		list.deleteAll();
//		list.show();
////		System.err.println(list.head.data);
	}
}
