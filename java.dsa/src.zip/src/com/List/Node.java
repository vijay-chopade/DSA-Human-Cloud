package com.List;

public class Node {

	int data;
	Node next;
}
