package com.ServerAPI;

import java.util.ArrayList;
import java.util.Iterator;

public class Runner {

	public static void main(String[] args) {
		Menu stackMenu=new Menu(1, "Stack");
		stackMenu.addMI(new MenuItem(1, "Push"));
		stackMenu.addMI(new MenuItem(2, "Peek"));
		
		stackMenu.display1();
		
		//Runner.listData();
	}

//	public static void listData() {
//		
//		ArrayList<MenuItem> list = new ArrayList<>();
//		list.add(new MenuItem(1, "pop()", new Menu()));
//		list.add(new MenuItem(2, "push()", new Menu()));
//		list.add(new MenuItem(3, "peek()", new Menu()));
//
//		ArrayList<MenuItem> stack = new ArrayList<>();
//		stack.add(new MenuItem(1, "spop()", new Menu()));
//		stack.add(new MenuItem(2, "spush()", new Menu()));
//		stack.add(new MenuItem(3, "speek()", new Menu()));
//
//		ArrayList<MenuItem> queue = new ArrayList<>();
//		queue.add(new MenuItem(1, "qpop()", new Menu()));
//		queue.add(new MenuItem(2, "qpush()", new Menu()));
//		queue.add(new MenuItem(3, "qpeek()", new Menu()));
//
//		ArrayList<Menu> menulist = new ArrayList<>();
//		menulist.add(new Menu(1, "LinkedList", list));
//		menulist.add(new Menu(2, "Stack", stack));
//		menulist.add(new Menu(3, "Queue", queue));
//
//		Runner.form(menulist);
//		Runner.formi(list);
//		Runner.formi(queue);
//		Runner.formi(stack);
//
//	}

	public static void form(ArrayList<Menu> list) {

		Iterator<Menu> ite = list.iterator();
		while (ite.hasNext()) {
			Menu m = ite.next();
			System.out.println(m.getId() + " " + m.getName());
		}
		System.out.println();
	}

	public static void formi(ArrayList<MenuItem> list) {
		Iterator<MenuItem> ite = list.iterator();
		while (ite.hasNext()) {
			MenuItem m = ite.next();
			System.out.println(m.getId() + " " + m.getName());

		}
		System.out.println();
	}

}

//private static Scanner sc = new Scanner(System.in);

//public static void DataStructure() {
//	ArrayList<Menu> m = new ArrayList<>();
//	m.add(new Menu(1, "LinkedList"));
//	m.add(new Menu(2, "Queue"));
//	m.add(new Menu(3, "Stack"));
//	for (Menu x : m) {
//		System.out.println(x.getIndex() + " " + x.getDs() + " " + x.getMenu());
//	}
//	System.out.print("Enter input: ");
//	opration();
//}
//
//public static void opration() {
//	int op = Runner.sc.nextInt();
//	ArrayList<MenuItem> mi = new ArrayList<>();
//	mi.add(new MenuItem(1, "push()"));
//	mi.add(new MenuItem(2, "pop()"));
//	mi.add(new MenuItem(3, "peek()"));
//	for (MenuItem x : mi) {
//		System.out.println(x.getIndex() + " " + x.getOpration());
//	}
//
//}

//public static void main(String[] args) {
//	Runner.DataStructure();
//}
