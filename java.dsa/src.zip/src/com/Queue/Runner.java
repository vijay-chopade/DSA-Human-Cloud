package com.Queue;

public class Runner {

	public static void main(String[] args) {

//		Queue queue = new Queue();
//		queue.enqueue(67);
//		queue.enqueue(2);
//		queue.enqueue(5);
//		queue.enqueue(8);
//		queue.enqueue(9);
//		queue.show();
//		System.out.println(queue.dequeue());
////		queue.show();
////		System.out.println(queue.dequeue());
////		queue.show();
////		System.out.println(queue.dequeue());
////		queue.show();
////		System.out.println(queue.dequeue());
//		queue.enqueue(9);
//		queue.enqueue(9);
//		queue.enqueue(9);
//		queue.show();
	}
}
