package com.UserAPI;

public class APIRunner {

	public static void main(String[] args) {
		 APIController.run();
	}

}
